#==========================================
# Title:  QuickStart - Show Desktop
# Author: Hung Truong, Jannik Junker
# Date:   25 March 2020
#==========================================

(New-Object -ComObject shell.application).toggleDesktop()